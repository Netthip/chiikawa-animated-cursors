@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0..\Install.ps1" -Size 48
if errorlevel 1 echo Operation failed. See message above.
pause
