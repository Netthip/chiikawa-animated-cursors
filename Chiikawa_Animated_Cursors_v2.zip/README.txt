﻿CHIIKAWA ANIMATED CURSOR V2 / Windows 10 & 11
ชุดเคอร์เซอร์สำหรับใช้งานส่วนตัว | 17 สถานะ x 3 ขนาด

1. แตก ZIP ทั้งหมดก่อน (Extract All) ไม่เปิดจากภายใน ZIP
2. เลือกโฟลเดอร์ 32, 48 (แนะนำ) หรือ 64 แล้วเปิด Install.cmd
   ไม่ต้อง Run as administrator. Windows อาจขออนุญาตเรียกสคริปต์; หากไม่สะดวก ใช้วิธีติดตั้งด้วยตนเองด้านล่าง
3. ถ้าไม่เปลี่ยนทันที ให้ Sign out แล้ว Sign in ใหม่
4. เปลี่ยนขนาดได้โดยเปิด Install.cmd ในขนาดใหม่ (เก็บค่าก่อนติดตั้งครั้งแรกไว้)
5. คืนค่าก่อนติดตั้งด้วย Restore.cmd ที่โฟลเดอร์หลัก ส่วน Windows Default ให้เลือก Scheme: Windows Default ใน Mouse Properties

Manual: Settings > Bluetooth & devices > Mouse > Additional mouse settings > Pointers.
เลือกแต่ละสถานะ > Browse > เลือกไฟล์ .ani ที่ตรงกัน > Apply > OK. Save As หากต้องการบันทึก scheme.
ไฟล์ .cur คือภาพนิ่งสำหรับสำรอง ใช้แทน .ani ได้หากโปรแกรมไม่รองรับภาพเคลื่อนไหว.
หาก Restore.cmd ไม่พบ backup (เช่น ติดตั้งด้วยตนเอง) ให้เลือก scheme เดิมด้วย Mouse Properties.

Installer copies .ani files to %LOCALAPPDATA%\ChiikawaCursorV2; it changes only the 17 current-user cursor values.
Restore restores the pre-V2 values (including a previously installed custom pack, if any). It does not remove original V1 files.
Source: 8 frames of the approved GIF downloaded from the original chat, not the unavailable original PNG spritesheet.
All 17 roles reuse this same approved hopping animation; pink role-specific symbols and hotspots distinguish the roles, with animated loading dots for Wait and AppStarting.
The original face is not redrawn; reduced resolution may soften facial details, especially 32 px.
Preview.gif / Preview.png show the 48 px version enlarged 2x for clarity.
Windows may resize cursors according to accessibility/DPI settings; some apps supply their own cursor.

ROLE MAPPING
Normal select: Arrow.ani
Help select: Help.ani
Working in background: AppStarting.ani
Busy: Wait.ani
Precision select: Crosshair.ani
Text select: IBeam.ani
Handwriting: NWPen.ani
Unavailable: No.ani
Vertical resize: SizeNS.ani
Horizontal resize: SizeWE.ani
Diagonal resize NW-SE: SizeNWSE.ani
Diagonal resize NE-SW: SizeNESW.ani
Move: SizeAll.ani
Alternate select: UpArrow.ani
Link select: Hand.ani
Location select: Pin.ani
Person select: Person.ani
