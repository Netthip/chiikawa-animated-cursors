﻿Chiikawa — Animated Friends v3 | Personal fan art

Windows 10/11: แตก ZIP ก่อน เลือก Windows/96 (กลาง) หรือ Windows/128 (ใหญ่) แล้วดับเบิลคลิก Install.cmd ไม่ต้องใช้สิทธิ์ผู้ดูแลระบบ หากยังไม่เปลี่ยนให้ลงชื่อออกแล้วเข้าใหม่
คืนค่า: Windows/Restore.cmd จะคืนค่าก่อนติดตั้ง Animated Friends v3 ครั้งแรก รวมถึงธีมเดิมหรือ v2 ที่เคยใช้ ทั้งสองชุดใช้ข้อมูลสำรองเดียวกัน จึงสลับชุดได้โดยไม่ทับค่าก่อนติดตั้ง
Bonus: ไฟล์ Arrow แบบอื่นๆ ในโฟลเดอร์ Bonus เลือกได้ด้วยตนเองใน Mouse Properties > Pointers > Normal Select > Browse. .cur คือภาพนิ่งสำรอง
หากขนาดแสดงผลไม่ตรงตามต้องการ สามารถปรับ Pointer size ใน Windows Accessibility ได้ แต่ Windows/DPI/โปรแกรมบางตัวอาจย่อหรือแทนที่เคอร์เซอร์

macOS: ต้องใช้ Mousecape (https://github.com/alexzielenski/Mousecape/releases) ติดตั้ง Helper Tool ตามคู่มือ จากนั้นเปิดไฟล์ .cape ขนาด 96 หรือ 128 ใน macOS/ และ Apply. คลิกขวาที่ cape > Restore Default (หรือ Mousecape > Restore Defaults ตามรุ่น) เพื่อคืนค่า. 96/128 คือขนาด logical points, มีภาพ 1x/2x สำหรับ Retina. macOS บางรุ่นจำกัดการแทนที่เคอร์เซอร์หรือไม่รองรับ Mousecape; ชุดนี้ยังไม่ได้ทดสอบบนเครื่อง Mac จริง
Mousecape มี 41 cursor identifiers โดยรวม aliases สำหรับสถานะที่เทียบได้ ไม่ได้แทนทุกสถานะของ Windows แบบหนึ่งต่อหนึ่ง

17 Windows roles × 2 sizes; 3 bonus Arrow variants per size. 12 frames, 100 ms per frame, different gentle bounces, tilts, squash, rocking, and motion for different roles. Cursor symbols and hotspots stay fixed. Original generated pose sheet and animated previews included. Animation is motion of whole pose, not hand-drawn frame-by-frame facial changes.
Verified 80 Windows files using LoadImageW without modifying the actual cursor scheme. ANI/CUR headers, dimensions, transparency mask, frame counts, hotspots and changing frames validated. Both Mousecape plists decoded and their PNG strips checked; live Mac and Windows installation/restore not tested.
