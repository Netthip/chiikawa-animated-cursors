$ErrorActionPreference = 'Stop'
$backup = Join-Path $env:LOCALAPPDATA 'AnimatedFriendsV3\backup.json'
if (!(Test-Path $backup)) { Write-Host 'No Animated Friends backup found. Use Mouse Properties > Pointers to select Windows Default.'; exit 1 }
$snapshot = Get-Content -LiteralPath $backup -Raw | ConvertFrom-Json
$key = [Microsoft.Win32.Registry]::CurrentUser.OpenSubKey('Control Panel\Cursors',$true)
foreach ($r in $snapshot) {
  if ($r.Exists) { $key.SetValue($r.Name,$r.Value,[Microsoft.Win32.RegistryValueKind]$r.Kind) }
  else { $key.DeleteValue($r.Name,$false) }
}
$key.Close()
Add-Type -TypeDefinition 'using System; using System.Runtime.InteropServices; public class CursorRefresh { [DllImport("user32.dll", SetLastError=true)] public static extern bool SystemParametersInfo(uint a,uint b,IntPtr c,uint d); }'
if (![CursorRefresh]::SystemParametersInfo(0x57,0,[IntPtr]::Zero,2)) { Write-Warning 'Sign out and sign in again to refresh.' }
Move-Item -LiteralPath $backup -Destination ($backup + '.restored') -Force
Write-Host 'Original cursor settings restored.'
