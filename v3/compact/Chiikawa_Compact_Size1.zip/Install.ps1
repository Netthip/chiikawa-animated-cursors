$Size = '32';
$ErrorActionPreference = 'Stop'
$roles = @('Arrow','Help','AppStarting','Wait','Crosshair','IBeam','NWPen','No','SizeNS','SizeWE','SizeNWSE','SizeNESW','SizeAll','UpArrow','Hand','Pin','Person')

$base = Join-Path $env:LOCALAPPDATA 'AnimatedFriendsV3'
$dest = Join-Path (Join-Path $base 'Chiikawa') $Size
$backup = Join-Path $base 'backup.json'
$source = $PSScriptRoot
foreach ($r in $roles) { if (!(Test-Path (Join-Path $source "$r.ani"))) { throw "Missing $r.ani" } }
New-Item -ItemType Directory -Force $dest | Out-Null
Copy-Item (Join-Path $source '*.ani') $dest -Force
$key = [Microsoft.Win32.Registry]::CurrentUser.OpenSubKey('Control Panel\Cursors',$true)
if (!(Test-Path $backup)) {
  $snapshot = foreach ($r in $roles) {
    if ($key.GetValueNames() -contains $r) {
      @{Name=$r; Exists=$true; Kind=$key.GetValueKind($r).ToString(); Value=$key.GetValue($r,$null,[Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)}
    } else { @{Name=$r; Exists=$false} }
  }
  $snapshot | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath $backup -Encoding UTF8
}
$snapshot = @(Get-Content -LiteralPath $backup -Raw | ConvertFrom-Json)
if ($snapshot.Name -notcontains 'CursorBaseSize') {
  if ($key.GetValueNames() -contains 'CursorBaseSize') {
    $snapshot += @{Name='CursorBaseSize'; Exists=$true; Kind=$key.GetValueKind('CursorBaseSize').ToString(); Value=$key.GetValue('CursorBaseSize')}
  } else { $snapshot += @{Name='CursorBaseSize'; Exists=$false} }
  $snapshot | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath $backup -Encoding UTF8
}
$key.SetValue('CursorBaseSize',32,[Microsoft.Win32.RegistryValueKind]::DWord)
foreach ($r in $roles) { $key.SetValue($r,(Join-Path $dest "$r.ani"),[Microsoft.Win32.RegistryValueKind]::String) }
$key.Close()
Add-Type -TypeDefinition 'using System; using System.Runtime.InteropServices; public class CursorRefresh { [DllImport("user32.dll", SetLastError=true)] public static extern bool SystemParametersInfo(uint a,uint b,IntPtr c,uint d); }'
if (![CursorRefresh]::SystemParametersInfo(0x57,0,[IntPtr]::Zero,2)) { Write-Warning 'Sign out and sign in again to refresh.' }
Write-Host 'Installed! Your original cursor settings were backed up.'
