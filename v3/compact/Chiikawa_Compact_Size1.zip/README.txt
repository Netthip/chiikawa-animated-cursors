﻿Chiikawa Compact — Windows pointer Size 1 (32 px)

แตกไฟล์ ZIP แล้วเปิด Install.cmd เพื่อใช้ชุดนี้และตั้ง CursorBaseSize เป็น 32 px (ขนาด 1 บน Windows ของกิ๊ฟ) โดยจะเก็บข้อมูลเคอร์เซอร์และขนาดก่อนเปลี่ยนไว้ใน backup ร่วมของ Animated Friends v3. ใช้ Restore.cmd เพื่อคืนค่าก่อนติดตั้ง v3/Compact หรือกลับชุดเดิมโดยเปิด Install.cmd ของ v3 ขนาดเดิม. การตั้งขนาดเมาส์มีผลกับทั้งสองจอ. หาก Windows ไม่รีเฟรชทันทีให้ลงชื่อออกแล้วเข้าใหม่.

17 roles, 3 bonus normal pointers, native 32 px, 12 frames. Larger characters, stronger contrast and smaller role symbols for better visibility when Windows renders at pointer size 1. The original 96 and 128 packages and macOS files remain unchanged. All 40 cursor files loaded through native Windows APIs; actual full-scheme install and restore have not been tested. Chiikawa normal pointer preserves the exact sample that Gift tested successfully on the 27-inch display.
