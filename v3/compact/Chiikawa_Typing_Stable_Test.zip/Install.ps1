$ErrorActionPreference = 'Stop'
$folder = Join-Path $env:LOCALAPPDATA 'AnimatedFriendsV3\TypingStable'
$backup = Join-Path $folder 'previous_ibeam.txt'
$key = 'HKCU:\Control Panel\Cursors'
$previous = (Get-ItemProperty -Path $key -Name IBeam).IBeam
New-Item -ItemType Directory -Path $folder -Force | Out-Null
$file = Join-Path $folder 'IBeam_Stable.cur'
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'IBeam_Stable.cur') -Destination $file -Force
if (!(Test-Path -LiteralPath $backup)) { Set-Content -LiteralPath $backup -Value $previous -Encoding UTF8 }
Add-Type -TypeDefinition 'using System; using System.Runtime.InteropServices; public static class TypingRefresh { [DllImport("user32.dll", SetLastError=true)] public static extern bool SystemParametersInfo(uint a,uint b,IntPtr c,uint d); }'
Set-ItemProperty -Path $key -Name IBeam -Value $file
if (![TypingRefresh]::SystemParametersInfo(0x57,0,[IntPtr]::Zero,2)) {
    Set-ItemProperty -Path $key -Name IBeam -Value $previous
    [TypingRefresh]::SystemParametersInfo(0x57,0,[IntPtr]::Zero,2) | Out-Null
    throw 'Refresh failed; original text pointer restored.'
}
Write-Host 'Text select is now a steady cursor. All other pointer roles and system typing preferences were left unchanged.'
