Chiikawa Typing Stable — Windows Size 1 test

This optional add-on changes only Text Select (IBeam) to the static first frame of the existing Compact cursor. All other roles remain animated and unchanged. The hotspot and artwork are identical to the original Compact design.

1. Extract the ZIP and run Install.cmd to install the static Text Select cursor. Restore.cmd restores the previous cursor.
2. If the mouse pointer disappears while typing, Windows may be set to hide it. Open Mouse Properties > Pointer Options and uncheck Hide pointer while typing if you want the mouse pointer to remain visible while typing. Some applications may still hide their mouse pointers independently.

This add-on does not change the system's Hide pointer while typing preference or the insertion caret.
