@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Restore.ps1"
if errorlevel 1 echo Operation failed. See message above.
pause
