$ErrorActionPreference = 'Stop'
$folder = Join-Path $env:LOCALAPPDATA 'AnimatedFriendsV3\TypingStable'
$backup = Join-Path $folder 'previous_ibeam.txt'
if (!(Test-Path -LiteralPath $backup)) { throw 'No Typing Stable backup found.' }
$key = 'HKCU:\Control Panel\Cursors'
$previous = (Get-Content -LiteralPath $backup -Raw).TrimEnd("`r","`n")
Add-Type -TypeDefinition 'using System; using System.Runtime.InteropServices; public static class TypingRestore { [DllImport("user32.dll", SetLastError=true)] public static extern bool SystemParametersInfo(uint a,uint b,IntPtr c,uint d); }'
Set-ItemProperty -Path $key -Name IBeam -Value $previous
if (![TypingRestore]::SystemParametersInfo(0x57,0,[IntPtr]::Zero,2)) { throw 'Refresh failed. Sign out and sign in.' }
Move-Item -LiteralPath $backup -Destination ($backup+'.restored') -Force
Write-Host 'Original text select cursor restored.'
