﻿Kurimanju Animated Friends — MaCursor v3.1 (test edition)

macOS 13 Ventura or later. MaCursor's project README advertises macOS 26 Tahoe and 27 Golden Gate support.
1. Download MaCursor from https://github.com/writronic/MaCursor/releases
2. Install and open MaCursor, then follow its helper-tool setup.
3. Extract this ZIP and double-click the .cursor file, or use File > Import Theme. Select the theme and click Apply.
4. Adjust Cursor Scale in MaCursor to suit your monitor. Start at 1x.

This is a native MaCursor XML theme, not a Mousecape .cape renamed to .cursor. 32 logical points, 1x/2x/5x transparent representations, 12 frames per loop and 45 mapped cursor identifiers, including ArrowS/IBeamS for current macOS. Mac-specific roles with no equivalent design are intentionally left at defaults.
All entries and PNG strips were validated locally against MaCursor's source schema; we do not have a macOS test machine. Actual import, animation, apply and restore on macOS need testing. The 1x images are the native Compact Windows artwork; 2x/5x were rendered from the original pose artwork.

MaCursor source and documentation: https://github.com/writronic/MaCursor
Unofficial personal-use fan art. No affiliation with MaCursor or the characters' creators.
