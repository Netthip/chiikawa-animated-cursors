﻿Kurimanju Animated Friends — MaCursor v3.2 Retina (test edition)

macOS 13 Ventura or later. MaCursor's project README advertises macOS 26 Tahoe and 27 Golden Gate support.
1. Download MaCursor from https://github.com/writronic/MaCursor/releases
2. Install and open MaCursor, then follow its helper-tool setup.
3. Extract this ZIP and double-click the .cursor file, or use File > Import Theme. Select the NEW v3.2 Retina theme and click Apply.
4. Adjust Cursor Scale within MaCursor, not macOS system settings. Start at 1x.

32 logical points, 1x/2x/5x/10x transparent representations, 12 frames per loop and 45 mapped cursor identifiers. The 1x image is unchanged; high-resolution role symbols are redrawn as smooth shapes instead of enlarging Windows pixels. The character artwork is rendered from the source pose at each scale. No system settings are modified by this theme file.
All entries and PNG strips passed local structural validation against MaCursor's source schema; v3.1 was imported by a Mac user, but actual v3.2 import/playback/restore remain to be tested on Mac.

MaCursor source and documentation: https://github.com/writronic/MaCursor
Unofficial personal-use fan art. No affiliation with MaCursor or the characters' creators.
